import { makeStyles, Theme, createStyles, fade, List, ListItem, Tooltip, ListItemIcon, CssBaseline, AppBar, Toolbar, Typography, InputBase, Box, IconButton, Button, Drawer } from "@material-ui/core";
import { AccountCircle } from "@material-ui/icons";
import React, { useState, useEffect } from "react";
import { Route, Switch, useHistory } from "react-router-dom";
import IconDetails from "../utils/IconDetails";
import SearchIcon from '@material-ui/icons/Search';
import HeadsetMicIcon from '@material-ui/icons/HeadsetMic';
import ForumIcon from '@material-ui/icons/Forum';
import ExpenseTracker from '../assets/images/expense-tracker.png'
import AccountCircleRoundedIcon from '@material-ui/icons/AccountCircleRounded';
import AccountTreeRoundedIcon from '@material-ui/icons/AccountTreeRounded';
import EventRoundedIcon from '@material-ui/icons/EventRounded';
import LabelImportantRoundedIcon from '@material-ui/icons/LabelImportantRounded';
import ExplicitRoundedIcon from '@material-ui/icons/ExplicitRounded';

import Expense from '../components/expense/expense';
let drawerWidth = 140;

const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        root: {
            display: 'flex',
            // '& .MuiListItemIcon-root': {
            // 	marginLeft: '35%'
            // }
        },
        appBar: {
            width: `calc(100% - ${drawerWidth}px)`,
            marginLeft: drawerWidth,
            backgroundColor: '#262b40',
            color: 'white'
        },
        search: {
            position: 'relative',
            color: 'white',
            display: 'flex',
            flexDirection: 'row-reverse',
            borderRadius: 20,
            backgroundColor: fade("#A6A6A6", 0.15),
            '&:hover': {
                backgroundColor: fade('#DEDEDE', 0.25),
            },
            marginRight: theme.spacing(2),
            marginLeft: 0,
            borderColor: '#000000',
            width: '30%',
            [theme.breakpoints.up('sm')]: {
                marginLeft: theme.spacing(3),
                width: 'auto',
            }
        },
        searchIcon: {
            padding: theme.spacing(0, 2),
            height: '100%',
            position: 'absolute',
            pointerEvents: 'none',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
        },
        inputRoot: {
            color: 'inherit',
            marginRight: '18%'
        },
        inputInput: {
            padding: theme.spacing(1, 1, 1, 0),
            // vertical padding + font size from searchIcon
            paddingLeft: `calc(1em + ${theme.spacing(4)}px)`,
            transition: theme.transitions.create('width'),
            width: '100%',
            [theme.breakpoints.up('md')]: {
                width: '20ch',
            },
        },
        menuButton: {
            marginRight: theme.spacing(2),
        },
        drawer: {
            width: drawerWidth,
            // flexShrink: 0,
        },
        drawerPaper: {
            width: drawerWidth,
        },
        // necessary for content to be below app bar
        toolbar: theme.mixins.toolbar,
        content: {
            flexGrow: 1,
            backgroundColor: theme.palette.background.default,
            padding: theme.spacing(1),
        },
        update: {
            fontSize: "0.7rem",
            height: 17,
            lineheight: 15,
            minWidth: 15,
            textAlign: "center",
            marginLeft: 2,
            marginTop: '6%',
            borderRadius: 10,
            color: "white",
            backgroundColor: "lightgray",
            padding: "0 3px",
        }
    }),
);

const navigation = {
    "0": {
        "sortOrder": "0",
        "icon": 'Dashboard',
        "displayName": "Dashboard",
        "path": "/dashboard"
    },
    "1": {
        "sortOrder": "1",
        "icon": "ExplicitRounded",
        "displayName": "Expense Tracker",
        "path": "/expense-tracker"
    },
    "2": {
        "sortOrder": "2",
        "icon": "LabelImportantRounded",
        "displayName": "Income Tracker",
        "path": "/income-tracker"
    },
    "3": {
        "sortOrder": "3",
        "icon": "EventRounded",
        "displayName": "EMI",
        "path": "/emi-details"
    },
    "4": {
        "sortOrder": "4",
        "icon": "AccountTreeRounded",
        "displayName": "Projects",
        "path": "/project"
    },
    "5": {
        "sortOrder": "5",
        "icon": "AccountCircleRounded",
        "displayName": "Profile",
        "path": "/profile"
    }
}

export default function Dashboard(props: any) {

    const classes = useStyles();
    const history = useHistory();
    const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
    const open = Boolean(anchorEl);
    const [cartQty, setCartQty] = useState(4);
    const [navContent, setNavContent]: any = useState({
        "menu": {},
        "menuIndex": "0",
        "subMenuIndex": "0"
    })

    const onMainMenuClick = (menuIndex: string) => {
        const menuData: any = { ...navContent }
        menuData["menuIndex"] = menuIndex
        console.log("menu index", menuData.menu[menuIndex].path)
        history.push(menuData.menu[menuIndex].path)
        setNavContent(menuData)
    }

    const handleMenu = (event: React.MouseEvent<HTMLElement>) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = (instruction: any) => {
        setAnchorEl(null);
        if (instruction == "logout") {
        }

    };
    useEffect(() => {
        setNavContent({
            "menu": navigation,
            "menuIndex": "0",
            "subMenuIndex": "0"
        })
        // history.push("/dashboard")
    }, [])

    const renderMainMenu = () => {
        return (
            <List style={{ marginTop: '10px' }}>
                {Object.keys(navContent.menu).sort().map((navItem: any, index: any) => (
                    <ListItem
                        onClick={() => onMainMenuClick(navItem)}
                        style={(navContent["menu"][navItem]["sortOrder"] === navContent.menuIndex) ? {
                            height: '50px'
                            // backgroundColor: '#0078D7',
                            // borderTopLeftRadius: '10px',
                            // borderBottomLeftRadius: '10px'
                        } : { height: '50px' }} button key={navContent["menu"][navItem]["AppId"]}>
                        <Tooltip title={navContent["menu"][navItem]["displayName"]}>
                            <ListItemIcon style={{ marginLeft: '34%' }} >
                                <IconDetails icon={navContent["menu"][navItem].icon}></IconDetails>
                            </ListItemIcon>
                        </Tooltip>
                    </ListItem>
                ))}
            </List>
        )
    }

    return (
        <div className={classes.root}>
            <CssBaseline />
            <AppBar position="fixed" className={classes.appBar} >
                <Toolbar style={{ justifyContent: 'space-between' }} >
                    <div style={{ display: 'flex' }}>
                        <Typography variant="h6" noWrap color="primary">
                            Hi! Supriya
                        </Typography>
                        {/* <div className={classes.search} style={{ flex: 0.5 }}>
                            <InputBase
                                placeholder="Type Something"
                                classes={{
                                    root: classes.inputRoot,
                                    input: classes.inputInput,
                                }}
                                inputProps={{ 'aria-label': 'search' }}
                            />
                            <div className={classes.searchIcon}>
                                <SearchIcon />
                            </div>
                        </div> */}
                    </div>
                    <div style={{ display: 'flex' }}>
                        {/* <Box display="flex" marginLeft="2%" marginTop='4%'>
                            <ForumIcon
                                style={{ color: "#757575", cursor: "pointer" }}
                                onClick={(event: any) => {
                                    // history.push('/message');
                                }} />
                            {cartQty !== 0 ? (
                                <div className={classes.update}>{cartQty}</div>
                            ) : null}
                        </Box> */}
                        <div style={{ display: 'flex', marginLeft: "2%" }}>
                            <IconButton
                                aria-label="account of current user"
                                aria-controls="menu-appbar"
                                aria-haspopup="true"
                                onClick={handleMenu}
                                color="inherit"
                            >
                                <AccountCircle style={{ color: '#0078D7' }} />
                            </IconButton>
                            <Typography style={{ color: '#3572A7', fontSize: '12px', fontWeight: 'bold', marginTop: '11%', width: 100 }}>Supriya Ghosal</Typography>
                        </div>
                    </div>
                </Toolbar>
            </AppBar>

            <Drawer
                className={classes.drawer}
                variant="permanent"
                classes={{
                    paper: classes.drawerPaper,
                }}
                anchor="left"
            >
                {/* <Divider /> */}
                <div style={{
                    display: "flex",
                    flexDirection: 'row',
                    height: '100%'
                }}>
                    <div
                        style={{
                            display: "flex",
                            flexDirection: 'column',
                            width: '100%',
                            backgroundColor: '#004f96',
                            height: '100%'
                        }}
                    >
                        <div style={{
                            height: '17%', display: 'flex', justifyContent: 'center', alignContent: 'center',
                            backgroundColor: '#262b40',
                            // color: 'white'
                        }}>
                            <img src={ExpenseTracker} style={{ width: '55%', height: 65, marginTop: '10px' }} />
                        </div>
                        <div style={{
                            height: '83%',
                            backgroundColor: '#262b40',
                            color: 'white'
                        }}>
                            {renderMainMenu()}
                        </div>
                    </div>

                </div>

            </Drawer>
            <main className={classes.content}>
                <div className={classes.toolbar} />
                <Switch>
                    <Route path="/expense-tracker" component={Expense} />
                </Switch>
            </main>
        </div>
    );
}