import React, { useState, useEffect } from "react";
import { makeStyles, Theme, createStyles } from "@material-ui/core";
import Fab from '@material-ui/core/Fab';
import AddIcon from '@material-ui/icons/Add';
import AddExpense from './addExpense';

const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        root: {
            display: 'flex',
            // '& .MuiListItemIcon-root': {
            // 	marginLeft: '35%'
            // }
        },
        heading:{
            marginLeft: '2%'
        },
        addButton :{
            height: '2%',
            width: '3%',
            marginTop: '5%',
            marginLeft: '-10%',
        },
        heading2:{
            height: '12%',
            width: '11%',
            marginTop: '5%',
            marginLeft: '1%',
        }
    })
);

export default function Expense(props: any) {
    const classes = useStyles();
    return (
        <div className={classes.root}>
            <h3 className={classes.heading}>Expense Tracker</h3>
            <Fab color="primary" aria-label="add" className={classes.addButton}>
            <AddIcon />
            </Fab>
            <h4 className={classes.heading2}>Add New Expense</h4>
            <AddExpense/>
        </div>
        
    );
}