import React, { useState, useEffect } from "react";
import { makeStyles, Theme, createStyles } from "@material-ui/core";
import ReactDOM from "react-dom";
import { Formik, Field, Form } from "formik";
import axios from 'axios';
import { DataGrid } from '@material-ui/data-grid';

const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        root: {
            display: 'flex',
            // '& .MuiListItemIcon-root': {
            // 	marginLeft: '35%'
            // }
        },
        heading:{
            marginLeft: '2%'
        },
        addButton :{
            height: '2%',
            width: '3%',
            marginTop: '5%',
            marginLeft: '-10%',
        },
        heading2:{
            height: '24%',
            width: '89%',
            marginTop: '10%',
            marginLeft: '-14%',
        },
        expenseType :{
            marginLeft: '1%'
        }
    })
);

export default function AddExpense(props: any) {
  const columns = [
    { field: 'id', headerName: 'ID', width: 100 },
    { field: 'expenseType', headerName: 'expenseType', width: 250 },
    { field: 'amount', headerName: 'amount', width: 250 },
    { field: 'details', headerName: 'details', width: 350 },
    { field: 'date', headerName: 'date', width: 150 },
  ];
  const rows = [
    { id: 1, expenseType: 'Gourav',details:'abbcd', amount: 12, date: 'Gourav'},
    { id: 2, name: 'Geek', age: 43 },
    { id: 3, name: 'Pranav', age: 41 },
  ];
  var baseUrl = 'localhost:8080/v1/expense/addexpense';
  let expenseObj = {
    "expenseType": "",
    "amount": "",
    "date": "",
    "details": "",
    "userId": 1,
    "monthlyExpenseTrackerId": "",
    "dailyExpenseTrackerId": ""
};
    const classes = useStyles();
    const [value, setValue] = useState(8);
    const handleChange = (event) => {
        console.log("name is : ",this.state.value);
           this.setState({value: event.target.value});  
    };
    const handleSubmit = (fields :any) => {
      expenseObj.expenseType = fields.expenseType;
      expenseObj.amount = fields.amount;
      expenseObj.date = fields.date;
      expenseObj.details = fields.details;
      console.log(expenseObj);
      axios({
        method: 'post',
        url: baseUrl,
        data: expenseObj,
        }).then(response => console.log(response.data));
      // axios.post(baseUrl, expenseObj)
      // .then(response => console.log(response.data));

  };
    return (
        <div className={classes.heading2}>
        <Formik
          initialValues={{ expenseType: "", date: "",amount:"", details: "" }}
        //   onSubmit={async values => {
        //     await new Promise(resolve => setTimeout(resolve, 500));
        //     alert(JSON.stringify(values, null, 2));
        //   }}
        onSubmit={handleSubmit}
        >
            
          <Form>
            <label htmlFor="Expense Type">Expense Type</label>
            <Field name="expenseType" type="text" className={classes.expenseType} />
           
            <label htmlFor="Date" className={classes.expenseType}>Date of Expense</label>
            <Field name="date" type="text" className={classes.expenseType} />

            <label htmlFor="Amount" className={classes.expenseType}>Amount</label>
            <Field name="amount" type="text" className={classes.expenseType} />

            <label htmlFor="Details" className={classes.expenseType}>Details</label>
            <Field name="details" type="text" className={classes.expenseType} />

            <button type="submit">Submit</button>
          </Form>
        </Formik>
        <div style={{ height: 287, width: '107%' }}>
        <DataGrid rows={rows} columns={columns} pageSize={1} />
        </div>
      </div>
    );
}